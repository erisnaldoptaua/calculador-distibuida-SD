package com.rpc

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

// Estrutura da requisição enviada pelo cliente
@Serializable
data class JsonRpcRequest(
    val jsonrpc: String = "2.0",
    val method: String,
    val params: JsonElement? = null,
    val id: Int
)

// Estrutura da resposta retornada pelo servidor
@Serializable
data class JsonRpcResponse(
    val jsonrpc: String = "2.0",
    val result: JsonElement? = null,
    val error: JsonRpcError? = null,
    val id: Int
)

@Serializable
data class JsonRpcError(
    val code: Int,
    val message: String
)

