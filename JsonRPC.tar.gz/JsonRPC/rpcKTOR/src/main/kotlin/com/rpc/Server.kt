package com.rpc

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.*

fun main() {
    println("Iniciando Servidor JSON-RPC (rpcKTOR) na porta 8080...")
    
    embeddedServer(Netty, port = 8080) {
        // Configura o plugin para interpretar requisições JSON automaticamente
        install(ContentNegotiation) {
            json()
        }

        routing {
            post("/rpc") {
                // Recebe e desserializa o objeto JsonRpcRequest vindo do cliente
                val request = call.receive<JsonRpcRequest>()
                
                var resultado: Double? = null
                var erro: JsonRpcError? = null

                try {
                    when (request.method) {
                        "soma" -> {
                            val params = request.params?.jsonArray
                            val a = params?.get(0)?.jsonPrimitive?.double ?: 0.0
                            val b = params?.get(1)?.jsonPrimitive?.double ?: 0.0
                            resultado = a + b
                        }
                        "subtracao" -> {
                            val params = request.params?.jsonArray
                            val a = params?.get(0)?.jsonPrimitive?.double ?: 0.0
                            val b = params?.get(1)?.jsonPrimitive?.double ?: 0.0
                            resultado = a - b
                        }
                        "multiplicacao" -> {
                            val params = request.params?.jsonArray
                            val a = params?.get(0)?.jsonPrimitive?.double ?: 0.0
                            val b = params?.get(1)?.jsonPrimitive?.double ?: 0.0
                            resultado = a * b
                        }
                        "divisao" -> {
                            val params = request.params?.jsonArray
                            val a = params?.get(0)?.jsonPrimitive?.double ?: 0.0
                            val b = params?.get(1)?.jsonPrimitive?.double ?: 0.0
                            if (b == 0.0) {
                                erro = JsonRpcError(-32602, "Divisão por zero não é permitida.")
                            } else {
                                resultado = a / b
                            }
                        }
                        "avaliarExpressao" -> {
                            val expr = request.params?.jsonArray?.get(0)?.jsonPrimitive?.content ?: ""
                            resultado = calcularExpressao(expr)
                        }
                        else -> {
                            erro = JsonRpcError(-32601, "Método '${request.method}' não encontrado.")
                        }
                    }
                } catch (e: Exception) {
                    erro = JsonRpcError(-32603, "Erro interno ao processar: ${e.message}")
                }

                // Monta a resposta no formato JSON-RPC 2.0
                val response = JsonRpcResponse(
                    result = resultado?.let { JsonPrimitive(it) },
                    error = erro,
                    id = request.id
                )

                call.respond(response)
            }
        }
    }.start(wait = true)
}

// Avaliador de expressão matemática em Kotlin puro
fun calcularExpressao(expr: String): Double {
    if (expr.isBlank()) return 0.0
    val exp = expr.replace("\\s+".toRegex(), "")
    
    return object {
        var pos = -1
        var ch = -1

        fun proximoChar() {
            ch = if (++pos < exp.length) exp[pos].code else -1
        }

        fun consumir(charParaConsumir: Int): Boolean {
            while (ch == ' '.code) proximoChar()
            if (ch == charParaConsumir) {
                proximoChar()
                return true
            }
            return false
        }

        fun analisar(): Double {
            proximoChar()
            val x = analisarExpressao()
            if (pos < exp.length) throw RuntimeException("Caractere inesperado: ${ch.toChar()}")
            return x
        }

        fun analisarExpressao(): Double {
            var x = analisarTermo()
            while (true) {
                if (consumir('+'.code)) x += analisarTermo()
                else if (consumir('-'.code)) x -= analisarTermo()
                else return x
            }
        }

        fun analisarTermo(): Double {
            var x = analisarFator()
            while (true) {
                if (consumir('*'.code)) x *= analisarFator()
                else if (consumir('/'.code)) x /= analisarFator()
                else return x
            }
        }

        fun analisarFator(): Double {
            if (consumir('+'.code)) return analisarFator()
            if (consumir('-'.code)) return -analisarFator()

            var x: Double
            val inicioPos = this.pos
            if (consumir('('.code)) {
                x = analisarExpressao()
                consumir(')'.code)
            } else if ((ch >= '0'.code && ch <= '9'.code) || ch == '.'.code) {
                while ((ch >= '0'.code && ch <= '9'.code) || ch == '.'.code) proximoChar()
                x = exp.substring(inicioPos, this.pos).toDouble()
            } else {
                throw RuntimeException("Caractere inválido: ${ch.toChar()}")
            }
            return x
        }
    }.analisar()
}