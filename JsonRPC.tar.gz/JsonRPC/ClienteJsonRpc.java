/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author taua
 */
import java.util.Locale;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class ClienteJsonRpc {

    // URL do servidor Ktor JSON-RPC
    private static final String SERVER_URL = "http://localhost:8080/rpc";
    //private static final String SERVER_URL = "http://srvsocket:8080/rpc";

    public static void main(String[] args) {
        // Cliente HTTP nativo do Java (leve e assíncrono)
        HttpClient client = HttpClient.newHttpClient();
        Scanner scanner = new Scanner(System.in);
        int opcao = -1;
        int id = 1;

        System.out.println("=== CLIENTE JAVA LEVE (JSON-RPC) ===");

        while (opcao != 0) {
            System.out.println("\n---------------------------------------------");
            System.out.println("1 - Operação Simples (soma, sub, mult, div)");
            System.out.println("2 - Expressão Numérica (ex: (10 + 15) * 4)");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            if (opcao == 1) {
                System.out.print("Digite o primeiro número: ");
                double n1 = scanner.nextDouble();
                System.out.print("Digite a operação (+, -, *, /): ");
                char op = scanner.next().charAt(0);
                System.out.print("Digite o segundo número: ");
                double n2 = scanner.nextDouble();

                String metodo = switch (op) {
                    case '+' -> "somar";
                    case '-' -> "subtracao";
                    case '*' -> "multiplicacao";
                    case '/' -> "divisao";
                    default -> "soma";
                };

                // Monta a string do JSON-RPC 2.0 manualmente
               /* String jsonBody = String.format(
                    "{\"jsonrpc\": \"2.0\", \"method\": \"%s\", \"params\": [%f, %f], \"id\": %d}",
                    metodo, n1, n2, id++
                );
*/
               // Monta a string do JSON-RPC 2.0 manualmente
                String jsonBody = String.format(Locale.US,
                    "{\"jsonrpc\": \"2.0\", \"method\": \"%s\", \"params\": [%.2f, %.2f], \"id\": %d}",
                    metodo, n1, n2, id++
                );
               
  
                
               enviarRequisicao(client, jsonBody);

            } else if (opcao == 2) {
                System.out.print("Digite a expressão: ");
                String expr = scanner.nextLine();

                // Escapa aspas para não quebrar a string do JSON
                String exprFormatada = expr.replace("\"", "\\\"");

                String jsonBody = String.format(
                    "{\"jsonrpc\": \"2.0\", \"method\": \"avaliarExpressao\", \"params\": [\"%s\"], \"id\": %d}",
                    exprFormatada, id++
                );

                enviarRequisicao(client, jsonBody);

            } else if (opcao == 0) {
                System.out.println("Encerrando o cliente Java.");
            } else {
                System.out.println("Opção inválida!");
            }
        }
        scanner.close();
    }

    private static void enviarRequisicao(HttpClient client, String jsonBody) {
        try {
            // Constrói a requisição HTTP POST com o JSON no corpo
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(SERVER_URL))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            // Envia a requisição e aguarda a resposta
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("\n[Enviado para o Servidor]: " + jsonBody);
            System.out.println("[Resposta JSON-RPC]: " + response.body());

        } catch (Exception e) {
            System.err.println("Erro ao comunicar com o servidor: " + e.getMessage());
        }
    }
}
